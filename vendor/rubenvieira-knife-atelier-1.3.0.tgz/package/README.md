# Knife Atelier

The quiet beauty of a perfect edge. A premium digital knife showroom and the shared knife collection for Ruben's cutting experiments.

**[Open the atelier](https://play.rubenv.net/knife-atelier/)**

Six original designs: a 210 mm Gyuto, 180 mm Santoku with recessed granton pockets, 165 mm Nakiri, 130 mm Petty, 270 mm Sujihiki and 230 mm scalloped bread knife. Each has a closed tapered blade, a ground bevel, a fitted octagonal or riveted handle, a ferrule, and fine brass details. Layered steel, brushed satin and black forge finishes combine with walnut, olive wood or ebony. The octagonal handles have planar facets, small rounded corners and separate end grain; the western handles have two wooden scales, a visible full steel tang and flush brass rivets. Generated photographic wood albedos have pore-derived bump and roughness maps with an oiled finish. Directional steel grain and the maker's etch are baked Canvas textures; all texture sources ship with the app and library.

These are original digital objects, with no physical store or payment flow. All code and original models are MIT licensed; the GitHub repository remains private. Three.js is MIT; the bundled DM Sans font uses the SIL Open Font License.

## Explore

Drag to orbit; wheel or pinch to zoom; right-drag or two fingers to pan. Inspect, Turntable and Close view control the presentation. Collection holds the six knives, Steel and Timber change their materials, and Light switches between studio and daylight. Sound starts off. Save a picture exports the canvas. Take it with you exports the current configuration as a self-contained GLB or JSON cutting-edge metadata.

The display centres each knife using its actual geometry, with a measured contact clearance above the plinth. The knife and plinth share one vertical turntable axis. Home view fits their full rotation envelope into the space between the page text and controls, including on phones. Display transforms stay on a parent, so exported knives retain their original cutting coordinates.

Keys: `1` Inspect, `2` Turntable, `3` Close view, `C` Collection, arrows previous/next knife, `Space` pause, `R` reset view, `H` hide the interface, `?` About.

## Use in an existing or new experiment

The showroom and exports use the same factory in `src/library/knife-kit.ts`; there is no separate, lower-quality asset set.

### Copy the library

Copy `src/library/` into your experiment. With Three.js available:

```ts
import { createKnife, disposeKnife, loadKnifeTextures } from './library/knife-kit';

await loadKnifeTextures(); // one preload for all three local timber maps
const knife = createKnife('gyuto', { finish: 'damascus', wood: 'walnut' });
scene.add(knife);

// Keep all positioning/animation in a parent or the model's local transform.
knife.scale.setScalar(30); // example: if one scene unit = 1/30 metre
knife.rotation.y = Math.PI / 2; // adapt your experiment's blade axis

const { grip, tip, edgePolyline, cuttingDirection } = knife.userData.knifeAtelier;
// Grip, tip and edgePolyline are LOCAL metre coordinates; transform to scene space.
const worldTip = knife.localToWorld(new THREE.Vector3(...tip));

// When replacing it:
scene.remove(knife);
disposeKnife(knife);
```

Copy the entire `src/library/` directory, including `textures/`. The factory creates geometry in Node as well; use `{ textures: false }` without a DOM. Full material textures require a browser Canvas and the one-time `loadKnifeTextures()` preload. Without preloading, DOM consumers receive a simple grain fallback. Every factory call owns its GPU resources independently; only image/canvas sources are cached. The original generated maps and exact built-in image-generation prompts are preserved in `assets/wood-source/`.

### Install the shared package

```sh
npm install https://play.rubenv.net/knife-atelier/library/packages/rubenvieira-knife-atelier-1.3.0.tgz
```

```ts
import { createKnife, loadKnifeTextures, mountCuttingKnife } from '@rubenvieira/knife-atelier';
await loadKnifeTextures();
const knife = createKnife('sujihiki', { finish: 'satin', wood: 'walnut' });
const tool = mountCuttingKnife(knife, { bladeLength: .235, origin: 'tip', axis: '-x' });
scene.add(tool); // tip at x=0, heel at x=.235, handle continuing towards +X
```

This versioned archive contains the compiled factory, bundled photographic maps and declarations. It has no install/build hooks and needs no private Git credentials. Three.js remains a peer dependency, so each experiment keeps one renderer instance. `library/packages/latest.json` reports the current version and npm integrity. Keep the URL and package lock pinned; update them together for a new collection revision. Published archive bytes are immutable. The source repository can still be installed by Git with an authorised key.

`mountCuttingKnife` uses one uniform scale and a parent transform to preserve the original model and metadata. Choose a heel, blade-centre or tip origin, and a blade axis of `+x`, `-x`, `+z` or `-z`. The working edge stays at y=0. `attachBladeOverlay` retains an experiment's custard, crumbs or cake filling on both blade faces and its bevel. Each tool still owns its cutting simulation. `group.userData.knifeLibrary` records the shared version, profile and mounting frame.

### Load a ready-made GLB

Download any customised knife from the showroom, or use the six versioned defaults:

```ts
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const { scene: knife } = await new GLTFLoader().loadAsync(
  'https://play.rubenv.net/knife-atelier/library/models/v1/gyuto.glb'
);
scene.add(knife);
```

Other names: `santoku.glb`, `nakiri.glb`, `petty.glb`, `sujihiki.glb`, `bread.glb`. Defaults use layered steel and walnut. `catalog.json` in the same folder lists the assets and their metadata. Play experiments share an origin and can load these URLs directly. For a different origin, copy the downloaded GLB into that project's assets. GLBs include texture images and standard PBR materials, so they can also be used in Blender and other glTF tools. Rendering depends on the consumer's lighting and support for glTF physical material extensions.

The ES module is served at `/knife-atelier/library/knife-kit.js` and imports `three` as a bare peer specifier; a browser import needs an import map, or use a bundler. Type declarations are served beside it.

## Coordinate and metadata contract

Version `1.0`, units **metres**. Blade heel is `(0,0,0)`, blade runs along `+X`, face normals point along `±Z`, handle runs along `−X`, cutting direction is `(0,−1,0)`. The grip is inside the handle. Sizes are design dimensions, not specifications of a real manufacturer's knife.

`knife.userData.knifeAtelier` contains ID, chosen finish and wood, blade length/height/spine thickness, grip, tip, cutting direction and a sampled local-space cutting polyline. GLTFExporter stores this under the root node's `extras.knifeAtelier`; GLTFLoader restores it to `userData.knifeAtelier`. Named component meshes can be inspected with `getObjectByName('blade')`, `'handle'`, `'ferrule'`, and `'brass_inlay'`.

This library provides the visible knife and cutting-edge coordinates. Existing experiments keep their own collision, cutting and material-deformation behaviour.

## Build and release

```sh
npm ci
npm run build -- --base=/knife-atelier/
npm test
npm run dev -- --port 4391 --base=/knife-atelier/
```

Build output contains the showroom, versioned GLBs, reusable ES module and TypeScript declarations. The Play release workflow builds this repository at an immutable commit with the correct Vite base path. A push alone never publishes it.

Browser QA and capture scripts use the local Play capture installation on codex-server. `?record` stops wall-clock advancement and hides every UI element; `window.atelier.advance(dt)`, `setRotation()`, `chooseKnife()`, `homeView()` and `setCamera()` provide deterministic capture hooks. `window.atelier.placement` reports measured contact clearance and projected screen bounds. Geometry tests check every knife through a full turn; browser QA checks framing against the actual interface on desktop, tablet and phone.
